p=/faststorage/home/siyang/Bin/MHC-typing/bin/MHC_database_construct.pl
perl $p /faststorage/home/siyang/Bin/MHC-typing/database/database_imgt b38 /faststorage/home/siyang/Bin/MHC-typing/database
